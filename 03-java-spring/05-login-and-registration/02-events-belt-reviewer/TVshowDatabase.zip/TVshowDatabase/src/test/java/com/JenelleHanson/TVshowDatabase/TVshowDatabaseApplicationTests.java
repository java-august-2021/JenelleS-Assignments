package com.JenelleHanson.TVshowDatabase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TVshowDatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
